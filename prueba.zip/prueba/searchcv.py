from createcv import professional_experience,academic_training, skills_or_certificates,cv,personal_references
def consultar_cv():
    if "personal_data" not in cv:
        print("No hay hojas de vida registradas.")
        return

    print("\nCONSULTA DE HOJA DE VIDA")
    print("1. Buscar por nombre")
    print("2. Buscar por cédula")
    print("3. Buscar por correo electrónico")
    print("4. Filtrar por años de experiencia")
    print("5. Filtrar por formación académica")
    print("6. Filtrar por habilidades")
    print("7. Ver hoja de vida completa")
    print("8. Ver por secciones")

    opcion = input("Seleccione una opción (1-8): ")

    if opcion == "1":
        nombre = input("Ingrese el nombre a buscar: ").lower()
        if nombre in cv["personal_data"]["nombre"].lower():
            print("Nombre encontrado:\n", cv["personal_data"])
        else:
            print("Nombre no encontrado.")

    elif opcion == "2":
        cedula = int(input("Ingrese la cédula a buscar: "))
        if cedula == cv["personal_data"]["cedula"][0]:
            print("Cédula encontrada:\n", cv["personal_data"])
        else:
            print("Cédula no encontrada.")

    elif opcion == "3":
        correo = input("Ingrese el correo electrónico a buscar: ").lower()
        if correo == cv["personal_data"]["correo"].lower():
            print("Correo encontrado:\n", cv["personal_data"])
        else:
            print("Correo no encontrado.")

    elif opcion == "4":
        anio = input("Ingrese un año para filtrar experiencia (ej: 2015): ")
        resultados = []
        for exp in professional_experience:
            if anio in exp["time"]:
                resultados.append(exp)
        if resultados:
            print("Experiencia encontrada:")
            for r in resultados:
                print(r)
        else:
            print("No se encontró experiencia en ese año.")

    elif opcion == "5":
        palabra = input("Ingrese título o institución a buscar: ").lower()
        resultados = []
        for form in academic_training:
            if palabra in form["titulo"].lower() or palabra in form["institute"].lower():
                resultados.append(form)
        if resultados:
            print("Formación encontrada:")
            for r in resultados:
                print(r)
        else:
            print("No se encontraron coincidencias.")

    elif opcion == "6":
        habilidad = input("Ingrese una habilidad a buscar: ").lower()
        resultados = []
        for hab in skills_or_certificates:
            if habilidad in hab["skills"].lower():
                resultados.append(hab)
        if resultados:
            print("Habilidades encontradas:")
            for r in resultados:
                print(r)
        else:
            print("No se encontraron habilidades coincidentes.")

    elif opcion == "7":
        print("\n--- HOJA DE VIDA COMPLETA ---")
        for clave, valor in cv.items():
            print(f"\n>> {clave.upper()}")
            print(valor)

    elif opcion == "8":
        print("\nSecciones disponibles:")
        for clave in cv.keys():
            print(f"- {clave}")
        seleccion = input("Ingrese el nombre exacto de la sección que desea ver: ")
        if seleccion in cv:
            print(f"\n>> {seleccion.upper()}")
            print(cv[seleccion])
        else:
            print("Sección no encontrada.")
    else:
        print("Opción inválida.")