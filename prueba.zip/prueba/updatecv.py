from createcv import professional_experience,academic_training, skills_or_certificates,cv,personal_references

def actualizar_cv():
    if "personal_data" not in cv:
        print("No hay hoja de vida registrada.")
        return

    print("\nACTUALIZAR HOJA DE VIDA")
    print("1. Añadir nueva experiencia laboral")
    print("2. Añadir nueva formación académica")
    print("3. Editar datos personales o de contacto")
    print("4. Agregar o cambiar habilidades y certificados")
    print("5. Agregar referencias personales")

    opcion = input("Seleccione una opción (1-5): ")

    # 1. Añadir nueva experiencia laboral
    if opcion == "1":
        while True:
            print("\nAÑADIR EXPERIENCIA LABORAL")
            company = input("Empresa: ")
            area = input("Cargo: ")
            funtion = input("Funciones: ")
            time = input("Tiempo de duración (ej: 2010-2015): ")

            professional_experience.append({
                "name": company,
                "area": area,
                "funtion": funtion,
                "time": time
            })

            if input("¿Deseas agregar otra experiencia? (S/N): ").lower() != 's':
                break

        cv["professional_experience"] = professional_experience
        print("Experiencia añadida exitosamente.")

    # 2. Añadir nueva formación académica
    elif opcion == "2":
        while True:
            print("\nAÑADIR FORMACIÓN ACADÉMICA")
            institute = input("Institución: ")
            title = input("Título adquirido: ")
            duration = input("Año de inicio y finalización (ej: 2010-2015): ")

            academic_training.append({
                "institute": institute,
                "titulo": title,
                "duracion": duration
            })

            if input("¿Deseas agregar otro título? (S/N): ").lower() != 's':
                break

        cv["academic_training"] = academic_training
        print("Formación académica añadida exitosamente.")

    # 3. Editar datos personales o de contacto
    elif opcion == "3":
        print("\nEDITAR DATOS PERSONALES")
        print("Datos actuales:")
        for key, value in cv["personal_data"].items():
            print(f"{key}: {value}")

        campo = input("¿Qué dato desea editar? (nombre, cedula, fecha_nacimiento, correo, telefono, direccion): ").lower()
        if campo in cv["personal_data"]:
            nuevo_valor = input(f"Ingrese el nuevo valor para {campo}: ")
            if campo == "cedula" or campo == "telefono":
                nuevo_valor = int(nuevo_valor)
            if campo in ["cedula", "fecha_nacimiento"]:
                cv["personal_data"][campo] = (nuevo_valor,)
            else:
                cv["personal_data"][campo] = nuevo_valor
            print("Dato actualizado correctamente.")
        else:
            print("Campo no válido.")

    # 4. Agregar o cambiar habilidades y certificados
    elif opcion == "4":
        while True:
            print("\nAÑADIR HABILIDADES Y CERTIFICADOS")
            skills = input("Ingrese habilidades separadas por coma: ")
            certificate = input("Nombre del certificado: ")
            date = input("Año del certificado (ej: 2010): ")

            skills_or_certificates.append({
                "name": certificate,
                "date": date,
                "skills": skills
            })

            if input("¿Deseas agregar más habilidades o certificados? (S/N): ").lower() != 's':
                break

        cv["skills_or_certificates"] = skills_or_certificates
        print("Habilidades/certificados actualizados exitosamente.")

    # 5. Agregar referencias personales
    elif opcion == "5":
        while True:
            print("\nAÑADIR REFERENCIAS PERSONALES")
            name = input("Nombre de la persona: ")
            relation = input("Parentesco: ")
            tel = int(input("Teléfono: "))

            personal_references.append({
                "name": name,
                "relation": relation,
                "tel": tel
            })

            if input("¿Deseas agregar otra referencia? (S/N): ").lower() != 's':
                break

        cv["personal_references"] = personal_references
        print("Referencias añadidas exitosamente.")

    else:
        print("Opción inválida.")